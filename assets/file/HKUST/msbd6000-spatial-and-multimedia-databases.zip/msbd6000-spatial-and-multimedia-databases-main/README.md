# MSBD6000 Spatial and Multimedia Databases

MSBD 6000 Data Mining, Fall 2021. All rights reserved by Lam Chun Ting Jeff